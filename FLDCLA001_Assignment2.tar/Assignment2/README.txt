IN ORDER TO RUN THIS APPLICATION:

1. To run the standard "Part One" program that reads in the "oklist-1.txt",
prints the students to a file "printAllStudents.txt", prints experimentation
with student numbers to "printStudent.txt" and the operations counts to
"Instrumentation.txt"

Call: \.AccessAVLApp.sh

2. To test the printStudent() method with a student number of your choosing

Call: \.AccessAVLApp.sh FLDCLA001

Where the String is your choice. Inverted commas are your choice to include

3. To experiment with different values of n from the experiment file
"firstnames-1.txt", appends the number of lines selected by the user, the
result of the search chosen by the user, as well as the find and insert
counts, to a file "comparisonsForN.txt". Please note that you are requred to
enter 10 values for n and 10 values for a student to be found.

Call: \.AccessAVLApp.sh 10

Where the number is your choice, as long as it is below 108