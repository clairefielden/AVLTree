import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Popup;
import javax.swing.PopupFactory;

/**
* PopUpFrame class used to generate a "Terminated Program" message at the end of the Application
* 
* @author Claire Fielden FLDCLA001
* 
*/

public class PopUpFrame extends JFrame implements ActionListener{
    Popup p;
    JFrame f;
    JPanel j;
    PopupFactory pf;
    
    public PopUpFrame()
    {
        f = new JFrame("pop");
  
        f.setSize(400, 400);
  
        pf = new PopupFactory();
        
        JLabel l = new JLabel("Program terminated!");
        
        JButton b19 = new JButton("OK");
        
        b19.addActionListener(this);
        
        j = new JPanel();
  
        j.setBackground(Color.blue);
        
        Font fo = new Font("BOLD", 1, 14);
  
        l.setFont(fo);
        
        j.add(l);
        j.add(b19);
  
        j.setLayout(new GridLayout(2, 1));
        
       p = pf.getPopup(f, j, 180, 100);
        
        f.add(j);

        f.show();
    }

    public void actionPerformed(ActionEvent e)
    {
    
        String s = e.getActionCommand();
        
        if (s.equals("OK")) {
            p.hide();
            p = pf.getPopup(f, j, 180, 100);
            System.exit(0);
        }
        else
            p.show();
    
    }
 
}

