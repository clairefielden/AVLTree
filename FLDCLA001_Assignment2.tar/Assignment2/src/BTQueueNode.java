

public class BTQueueNode<Student> {

       BinaryTreeNode<Student> node;
   BTQueueNode<Student> next;
   
   public BTQueueNode ( BinaryTreeNode<Student> n, BTQueueNode<Student> nxt )
   {
      node = n;
      next = nxt;
   }
}
