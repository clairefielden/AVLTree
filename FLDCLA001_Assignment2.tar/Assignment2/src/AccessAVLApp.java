import java.io.FileInputStream;
import java.io.DataInputStream;
import java.io.InputStreamReader;
import java.io.BufferedWriter;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
* AccessAVLApp is the main class used to run the program
* Reads in the specified file
* Puts the file into elements
* Puts the elements into an AVL Tree
* Writes the contents of the AVLTree to the specified textfile
* Experiments with the AVLTree
* 
* @author Claire Fielden FLDCLA001
* 
*/


public class AccessAVLApp {

public static AVLTree<Student> tree = new AVLTree<Student>();

/**
 * 
 * @param String s the string it will evaluate to see if it is an integer
 * @return the boolean true or false, based on whether the string is an integer or not
 */

public static boolean isInteger(String s) 
{
    try { 
        Integer.parseInt(s); 
    } catch(NumberFormatException e) { 
        return false; 
    } catch(NullPointerException e) {
        return false;
    }
    return true;
}

/**
 * Prints all the students in the AVLTree to a file
 */
       
    public static void printAllStudents() 
    {
    	tree.inOrder();
  
    }
 
 /**
 * 
 * @param String stID the student number that will be searched for in the AVLTree
 * @return the result of the searcg
 */
    
    public static String printStudent(String stID)
    {
        Student f1 = new Student(stID, "");
        
        if(tree.find(f1)!= null)
        {
        	f1 = tree.find(f1).getStudent();
        	return f1.getName();
        }
        else
        {
        	return "Access denied!";
        }
    }
    
    /**
 * 
 * @param String filename the name of the file to be read in
 * @throws FileNotFoundException - in case the path name does not exist
 */
    
public static void readInFile(String filename) throws FileNotFoundException 
{
	
    File f = new File("data/"+filename);
    Scanner scnr = new Scanner(f);

                while(scnr.hasNextLine())
                {
                    String sn = "";
                    String fn = "";
                    
                    String line2 = scnr.nextLine();

                        for(int j = 0; j<9;j++)
                        {
                            sn = sn+line2.charAt(j);
                        }
                        int count = 9;
                        
                        for (int l = count+1; l<line2.length(); l++)
                        {
                                fn = fn+line2.charAt(l);
                        }

                        Student element = new Student(sn, fn);
                        tree.insert(element);
                }

                scnr.close();
}

  /**
 * 
 * @param String filename the name of the file to be read in
 * @param int num the number of lines to be read in from the file
 * @throws FileNotFoundException - in case the path name does not exist
 */

public static void readInExperimentFile(String filename, int num) throws FileNotFoundException 
{
	
	File f = new File("data/"+filename);
    	Scanner scnr = new Scanner(f);
    	
    	int j = 0;

                while(scnr.hasNextLine())
                {
                j++;
                    String sn = "";
                    String fn = "";
                    
                    String line2 = scnr.nextLine();

                        sn = sn+j;
                        fn = line2;
                        
                        Student element = new Student(sn, fn);
                        tree.insert(element);
                }

                scnr.close();
	
	
	
}

  /**
 * 
 * @param String filename the name of the file to be written to
 * 
 */
public static void writeToFile(String filename)
{
    try {
      FileWriter myWriter = new FileWriter("data/"+filename);
      myWriter.write("Print student name of student numbers that don't exist:");
      myWriter.write("\nFLDCLA001: "+printStudent("FLDCLA001"));
      myWriter.write("\nXYZ123: "+printStudent("XYZ123"));
      myWriter.write("\n123456789: "+printStudent("123456789"));
      myWriter.write("\nPrint student name of student numbers that do exist:");
      myWriter.write("\nMLLNOA014: "+printStudent("MLLNOA014"));
      myWriter.write("\nWTBJAY001: "+printStudent("WTBJAY001"));
      myWriter.write("\nKHZOMA010: "+printStudent("KHZOMA010"));
      myWriter.write("\nNo parameters - empty: "+printStudent(""));
       myWriter.write("\nNo parameters - space: "+printStudent(" "));
        myWriter.write("\nNo parameters - 0: "+printStudent("0"));
      
      printAllStudents();
       
      myWriter.close();
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
    
}

  /**
 * 
 * @param String filename the name of the file to be written to
 * @param String sOut the result of the find operation
 * @param int num the length of the dataset experimented with
 * 
 */

public static void writeToExperimentFile(String filename, String sOut, int num)
{

    try
        {
        	
            FileWriter fw = new FileWriter("data/"+filename,true);
            fw.write("Number of lines: "+num);
            fw.write("\nResults of find: "+sOut+"\n");
            fw.write("Find count: "+AVLTree.FCOUNT+"\n");
            fw.write("Insert count: "+AVLTree.ICOUNT+"\n");
            fw.write("\n");
            fw.close();
        }
    catch(IOException ioe)
        {
            System.err.println("IOException: " + ioe.getMessage());
        }
      
    }
    
  /**
 * 
 * @param String filename the name of the file to be written to
 */

public static void printInstrument(String filename)
{
      try {
      FileWriter myWriter = new FileWriter("data/"+filename);
      
      myWriter.write("Instrumentation: "+AVLTree.FCOUNT+" comparison operations performed for find operation.\n");
      myWriter.write("Instrumentation: "+AVLTree.ICOUNT+" comparison operations performed for insert operation.");

      
      myWriter.close();
      
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }

}

  /**
 * 
 * @param int num the number of lines in the dataset
 * @param the scanner used to read in user input
 * @throws FileNotFoundException - in case the path name does not exist
 */

public static void Experiment(int num, Scanner u) throws FileNotFoundException
{
	File file = new File("data/PrintAllStudents.txt");
        	file.delete(); 
        	String ans = "";
        		
        		readInExperimentFile("firstnames-1.txt", num);
        		System.out.println("For the experiment, you need to select a name to find. Please type in a number?");
        		ans = u.next();
        		u.nextLine();	
		
        		String s = printStudent(ans);
        		
        		writeToExperimentFile("comparisonsForN.txt", s, num);

}

  /**
 * 
 * @param String[] args the array of arguments that the user will input
 * In this case, if there is an argument, it will be the user inputting the student number or the number of lines to be experimented with
 * @throws FileNotFoundException - in case the path name does not exist
 */
public static void main(String[] args) throws FileNotFoundException
    {
        if(args.length == 0)
        {
        	File file = new File("data/PrintAllStudents.txt");
        	file.delete(); 
        	
        	readInFile("oklist-1.txt");
        	writeToFile("printStudent.txt");
        	printInstrument("Instrumentation.txt");
        }
        else if (isInteger(args[0]))
        {
        	
        	
        	for(int e = 0; e<10; e++)
        	{
        	AVLTree.FCOUNT = 0;
        	AVLTree.ICOUNT = 0;
        	String ans = "";
        	boolean exit = false;
        	Scanner user_input = new Scanner( System.in );
        	int n = 0;
        	
        	if(e == 0)
        	{
        	
        		n = Integer.parseInt(args[0]);
        	
        	}
        	else
        	{
        		System.out.println("What is the value of n?");
        		ans = user_input.next();
        		n = Integer.parseInt(ans);
        	}
        	
        	if (n>107)
        	{
        		System.out.println("There are only 107 lines in the test file!");
        		System.out.println("Enter a new number n for the dataset?");
        	ans = user_input.next();
        	if(!isInteger(ans))
        	{
        		System.out.println("This is invalid! Exiting.");
        		exit = true;
        	}
        	else
        	{
        		n = Integer.parseInt(ans);
        	}
        	}
        	
        	if (exit == false)
        	{
        		Experiment(n, user_input);
        	}
  		
        }
        }
        else
        {
        	String argNum = "";
        	argNum = args[0];
        	readInFile("oklist-1.txt");
        	System.out.println(printStudent(argNum));
        }
        
       PopUpFrame frame = new PopUpFrame();
       frame.show();
        
     }
            
    }
