/**
* Student class used to create elements with a name and a "key"
* The key is the student number
* The experiment file has the ley as the line number
* Compares the string values of two students' student numbers in order to determine where a node with a specific Student should be placed
* 
* @author Claire Fielden FLDCLA001
* 
*/

class Student implements Comparable <Student>
{
    String studentNum;
    String name;
  	
    
    public Student (String n, String fn)
    {
        studentNum = n;
        name = fn;
    }
    
    public String toString ()
    {
        return studentNum+": "+name+"\n";
    }
    
        public String getNum()
    {
        return studentNum;
    }
    
    public String getName()
    {
        return name;
    }
    
    
       
   /**
 * 
 * @param String s the string that will be converted to an integer value
 * @return the integer value of the argument
 */
   
    
    public int findValue(String s)
    {
        int value = 0;
        for(int i = 0; i<s.length(); i++)
        {
            value = value+((int)(s.charAt(i))-97);
        }
        
      return value;
    }


   
   /**
 * 
 * @param Student other the element used to compare the current Student's data to
 * @return 1, 0, -1 depending on whether the elements' student numbers match or not
 */
   

    public int compareTo(Student other)
    {
        String s1 = studentNum;
        String s2 = other.studentNum;
	
        if (s1.equals(s2))
        {
        
        	return 0;
        }
        else
        {
        	int r1 = findValue(s1);
        	int r2 = findValue(s2);

        	if(r1>r2)
        	{
        		
        		return 1;
        	}
        	else
        	{
        	
        		return -1;
        	}
        }
        
    }
    }
