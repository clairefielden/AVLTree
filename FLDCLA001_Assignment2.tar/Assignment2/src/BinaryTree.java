import java.io.BufferedWriter;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
* BinaryTree is the class used to by the AVL Tree to visit and order its nodes
* @author Claire Fielden FLDCLA001
* 
*/


public class BinaryTree<Student> {

      BinaryTreeNode<Student> root;
   
   public BinaryTree ()
   {
      root = null;
   }
   
   public int getHeight ()
   {
      return getHeight (root);
   }   
   public int getHeight ( BinaryTreeNode<Student> node )
   {
      if (node == null)
         return -1;
      else
         return 1 + Math.max (getHeight (node.getLeft ()), getHeight (node.getRight ()));
   }
   
   public int getSize ()
   {
      return getSize (root);
   }   
   public int getSize ( BinaryTreeNode<Student> node )
   {
      if (node == null)
         return 0;
      else
         return 1 + getSize (node.getLeft ()) + getSize (node.getRight ());
   }
   
   /**
 * 
 * @param BinaryTreeNode<Student> node the node that is being "visited" and written to a file
 * @throws IO Exception - in case the data cannot bve written to that file (if the path is not found)
 */
   
   public void visit ( BinaryTreeNode<Student> node )
   {
      
       
    try
        {
            FileWriter fw = new FileWriter("data/PrintAllStudents.txt",true);
            fw.write(node.data+"\n");
            fw.close();
        }
    catch(IOException ioe)
        {
            System.err.println("IOException: " + ioe.getMessage());
        }
   }
   
   
   
   public void preOrder ()
   {
      preOrder (root);
   }
   public void preOrder ( BinaryTreeNode<Student> node )
   {
      if (node != null)
      {
         visit (node);
         preOrder (node.getLeft ());
         preOrder (node.getRight ());
      }   
   }

   public void postOrder ()
   {
      postOrder (root);
   }
   public void postOrder ( BinaryTreeNode<Student> node )
   {
      if (node != null)
      {
         postOrder (node.getLeft ());
         postOrder (node.getRight ());
         visit (node);
      }   
   }
   
   /**
 * 
 * The code used to call the inOrder() function in order to order the AVL Tree
 */

   public void inOrder ()
   {
      inOrder (root);
   }
   
   /**
 * 
 * @param BinaryTreeNode<Student> node the node whose left and rigfht children are being ordered - the node itself is being transferred to the visit() function
 */
   
   public void inOrder ( BinaryTreeNode<Student> node )
   {
      if (node != null)
      {
         inOrder (node.getLeft ());
         visit (node);
         inOrder (node.getRight ());
      }   
   }
   
  
   public void levelOrder ()
   {
      if (root == null)
         return;
      BTQueue<Student> q = new BTQueue<Student>();
      q.enQueue (root);
      BinaryTreeNode<Student> node;
      while ((node = q.getNext ()) != null)
      {
         visit (node);
         if (node.getLeft () != null)
            q.enQueue (node.getLeft ());
         if (node.getRight () != null)
            q.enQueue (node.getRight ());
      }
   }
}


