import java.io.FileInputStream;
import java.io.DataInputStream;
import java.io.InputStreamReader;
import java.io.BufferedWriter;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.*;

/**
* AVLTree is the class used to create AVLTrees
* Inserts, deletes and finds Student elements
* Counts the insert and find operations
* Balances the tree with rotations
* 
* @author Claire Fielden FLDCLA001
* 
*/

public class AVLTree<Student extends Comparable<? super Student>> extends BinaryTree<Student> {

  public static int FCOUNT = 0;
    public static int ICOUNT = 0;
 
   /**
 * 
 * @param BinaryTreeNode<Student> node the node to test the height for
 * @return The height of the node
 */
 
   public int height ( BinaryTreeNode<Student> node )
   {
      if (node != null)
         return node.height;
      return -1;
   }
   
    /**
 * 
 * @param BinaryTreeNode<Student> node test the balance factor for
 * @return The integer displaying whether or not the node is balanced
 */
 
   
   public int balanceFactor ( BinaryTreeNode<Student> node )
   {
   	
      return height (node.right) - height (node.left);
   }
   
      /**
 * 
 * @param BinaryTreeNode<Student> node the node whose height needs to be edited
 * 
 */
   
   public void fixHeight ( BinaryTreeNode<Student> node )
   {
      node.height = Math.max (height (node.left), height (node.right)) + 1;
   }
   
      /**
 * 
 * @param BinaryTreeNode<Student> p the node to be rotated right
 * @return The node that has replaced the argument node
 */
   
   public BinaryTreeNode<Student> rotateRight ( BinaryTreeNode<Student> p )
   {
      BinaryTreeNode<Student> q = p.left;
      p.left = q.right;
      q.right = p;
      fixHeight (p);
      fixHeight (q);
      return q;
   }
   
        /**
 * 
 * @param BinaryTreeNode<Student> p the node to be rotated left
 * @return The node that has replaced the argument node
 */
   

   public BinaryTreeNode<Student> rotateLeft ( BinaryTreeNode<Student> q )
   {
      BinaryTreeNode<Student> p = q.right;
      q.right = p.left;
      p.left = q;
      fixHeight (q);
      fixHeight (p);
      return p;
   }
   
        /**
 * 
 * @param BinaryTreeNode<Student> p the node that is tested to see if balancing is needed
 * @return The balanced node
 */
   
   
   public BinaryTreeNode<Student> balance ( BinaryTreeNode<Student> p )
   {
   	
      fixHeight (p);
      if (balanceFactor (p) == 2)
      {
         if (balanceFactor (p.right) < 0)
            p.right = rotateRight (p.right);
         return rotateLeft (p);
      }
      if (balanceFactor (p) == -2)
      {
         if (balanceFactor (p.left) > 0)
            p.left = rotateLeft (p.left);
         return rotateRight (p);
      }
      return p;
   }
   
        /**
 * 
 * @param Student d The student to be inserted into the AVLTree
 */
   

   public void insert ( Student d )
   {
      root = insert (d, root);
   }

/**
 * 
 * @param Student d the element that needs to be inserted into the tree
 * @param BinaryTreeNode<Student> node the node whose data the student's key is being compared to in order to see where to insert the student
 * @return The balanced node or a new node in which the Student d has been inserted
 */
   
   public BinaryTreeNode<Student> insert ( Student d, BinaryTreeNode<Student> node )
   {
     
      if (node == null)
      {
         return new BinaryTreeNode<Student> (d, null, null);
      }
      
      ICOUNT++;
      
      if (d.compareTo (node.data) <= 0)
         node.left = insert (d, node.left);
      else
         node.right = insert (d, node.right);
      return balance (node);
   }
   
           /**
 * 
 * @param Student d The student to be deleted from the AVLTree
 */
   
   
   public void delete ( Student d )
   {
      root = delete (d, root);
   }   
   
           /**
 * 
 * @param Student d the element that needs to be deleted from the tree
 * @param BinaryTreeNode<Student> node the node whose data the student's key is being compared to in order to see which node should be deleted
 * @return The balanced node
 */
   
   public BinaryTreeNode<Student> delete ( Student d, BinaryTreeNode<Student> node )
   {
      if (node == null) return null;
      if (d.compareTo (node.data) < 0)
         node.left = delete (d, node.left);
      else if (d.compareTo (node.data) > 0)
         node.right = delete (d, node.right);
      else
      {
         BinaryTreeNode<Student> q = node.left;
         BinaryTreeNode<Student> r = node.right;
         if (r == null)
            return q;
         BinaryTreeNode<Student> min = findMin (r);
         min.right = removeMin (r);
         min.left = q;
         return balance (min);
      }
      return balance (node);
   }
   
   
           /**
 * 
 * @param BinaryTreeNode<Student> node The node the code is starting at and traversing down the rest of the tree in order to find the minimum
 * @return The lowest leaf with the data of the smallest student number
 */
   public BinaryTreeNode<Student> findMin ( BinaryTreeNode<Student> node )
   {
      if (node.left != null)
         return findMin (node.left);
      else
         return node;
   }

           /**
 * 
 * @param BinaryTreeNode<Student> node The node the code is starting at to see if it is the smallest leaf 
 * @return The balanced node 
 */

   public BinaryTreeNode<Student> removeMin ( BinaryTreeNode<Student> node )
   {
      if (node.left == null)
         return node.right;
      node.left = removeMin (node.left);
      return balance (node);
   }

/**
 * 
 * @param Student d The student to be found in the AVLTree
 */

   public BinaryTreeNode<Student> find ( Student d )
   {
      if (root == null)
      {
         return null;
         }
      else
      {
         return find (d, root);
       }
   }
   
/**
 * 
 * @param Student d the element that needs to be found in the tree
 * @param BinaryTreeNode<Student> node the node whose data the student's key is being compared to in order to see if it has been found
 * @return The node the student data was found at - or null if it wasn't found
 */
   
   public BinaryTreeNode<Student> find ( Student d, BinaryTreeNode<Student> node )
   {
       FCOUNT= FCOUNT+2;
      if (d.compareTo (node.data) == 0)
      {
      	return node;
      }
      else if (d.compareTo (node.data) < 0)
      {
      	return (node.left == null) ? null : find (d, node.left);
      }
      else
      {
         return (node.right == null) ? null : find (d, node.right);
      }
   }
   
   
   
   public void treeOrder ()
   {
      treeOrder (root, 0);
   }
   public void treeOrder ( BinaryTreeNode<Student> node, int level )
   {
      if (node != null)
      {
         for ( int i=0; i<level; i++ )
         {
         	try
        {
            FileWriter fw = new FileWriter("data/PrintAllStudents.txt",true);
            fw.write(" ");
            fw.write(node.data+"\n");
            fw.close();
        }
    catch(IOException ioe)
        {
            System.err.println("IOException: " + ioe.getMessage());
        }
         }
         	treeOrder (node.left, level+1);
         	treeOrder (node.right, level+1);
         
      }
   }
}
