/**
* BinaryTreeNode is the class used to create nodes for the AVLTree
* Creates a node with Student data
* Allocates a height, left node and right node to a specific node
* 
* @author Claire Fielden FLDCLA001
* 
*/


public class BinaryTreeNode<Student>
{
   Student data;
   BinaryTreeNode<Student> left;
   BinaryTreeNode<Student> right;
   int height;
   
   /**
 * 
 * @param Student d the element used to create the BinaryTreeNode
 * @param BinaryTreeNode<Student> l the node that will become the left child
 * @param BinaryTreeNode<Student> r the node that will become the right child
 */
   
   public BinaryTreeNode ( Student d, BinaryTreeNode<Student> l, BinaryTreeNode<Student> r )
   {
      data = d;
      left = l;
      right = r;
      height = 0;
   }
   
   BinaryTreeNode<Student> getLeft () { return left; }
   BinaryTreeNode<Student> getRight () { return right; }
   
      
   /**
 * 
 * The method used to return the Student element at a specific node
 */
   
   public Student getStudent () { return data; }
}
