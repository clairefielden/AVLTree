

public class BTQueue<Student> {
    
    BTQueueNode<Student> head;
   BTQueueNode<Student> tail;
      
   public BTQueue ()
   {
      head = null;
      tail = null;
   }
   
   public BinaryTreeNode<Student> getNext ()
   {
      if (head == null)
         return null;
      BTQueueNode<Student> qnode = head;
      head = head.next;
      if ( head == null )
         tail = null;
      return qnode.node;
   }
   
   public void enQueue ( BinaryTreeNode<Student> node )
   {
      if (tail == null)
      {   
         tail = new BTQueueNode<Student> (node, null);
         head = tail;
      }   
      else
      {
         tail.next = new BTQueueNode<Student> (node, null);
         tail = tail.next;
      }   
   }   
    
}
