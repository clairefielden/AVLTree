/**
* BinarySearchTree class used to find, insert and delete elements from a Binary Search Tree
* 
* @author Claire Fielden FLDCLA001
* 
*/


public class BinarySearchTree<Student extends Comparable<? super Student>> extends BinaryTree<Student>
{

   public void insert ( Student d )
   {
      if (root == null)
         root = new BinaryTreeNode<Student> (d, null, null);
      else
         insert (d, root);
   }
   public void insert ( Student d, BinaryTreeNode<Student> node )
   {
      if (d.compareTo (node.data) <= 0)
      {
         if (node.left == null)
            node.left = new BinaryTreeNode<Student> (d, null, null);
         else
            insert (d, node.left);
      }
      else
      {
         if (node.right == null)
            node.right = new BinaryTreeNode<Student> (d, null, null);
         else
            insert (d, node.right);
      }
   }
   
   public BinaryTreeNode<Student> find ( Student d )
   {
      if (root == null)
         return null;
      else
         return find (d, root);
   }
   public BinaryTreeNode<Student> find ( Student d, BinaryTreeNode<Student> node )
   {
      if (d.compareTo (node.data) == 0) 
         return node;
      else if (d.compareTo (node.data) < 0)
         return (node.left == null) ? null : find (d, node.left);
      else
         return (node.right == null) ? null : find (d, node.right);
   }
   
   public void delete ( Student d )
   {
      root = delete (d, root);
   }   
   public BinaryTreeNode<Student> delete ( Student d, BinaryTreeNode<Student> node )
   {
      if (node == null) return null;
      if (d.compareTo (node.data) < 0)
         node.left = delete (d, node.left);
      else if (d.compareTo (node.data) > 0)
         node.right = delete (d, node.right);
      else if (node.left != null && node.right != null )
      {
         node.data = findMin (node.right).data;
         node.right = removeMin (node.right);
      }
      else
         if (node.left != null)
            node = node.left;
         else
            node = node.right;
      return node;
   }
   
   public BinaryTreeNode<Student> findMin ( BinaryTreeNode<Student> node )
   {
      if (node != null)
         while (node.left != null)
            node = node.left;
      return node;
   }

   public BinaryTreeNode<Student> removeMin ( BinaryTreeNode<Student> node )
   {
      if (node == null)
         return null;
      else if (node.left != null)
      {
         node.left = removeMin (node.left);
         return node;
      }
      else
         return node.right;
   }
   
}
